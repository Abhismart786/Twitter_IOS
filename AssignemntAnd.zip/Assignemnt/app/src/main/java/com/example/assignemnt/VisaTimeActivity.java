package com.example.assignemnt;



import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class VisaTimeActivity extends AppCompatActivity {

    private TimePicker timePicker;
    private EditText nameEditText;
    private Button submitButton;
    private TextView messageTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visa_time);

        timePicker = findViewById(R.id.timePicker);
        nameEditText = findViewById(R.id.nameEditText);
        submitButton = findViewById(R.id.submitButton);
        messageTextView = findViewById(R.id.messageTextView);
        messageTextView.setVisibility(View.GONE); // Initially hidden

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateAndSubmit();
            }
        });
    }

    private void validateAndSubmit() {
        String name = nameEditText.getText().toString().trim();
        int hour = timePicker.getCurrentHour();
        int minute = timePicker.getCurrentMinute();

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);

        // Check name
        if (name.isEmpty()) {
            showMessage("Name cannot be empty.");
            return;
        }

        // Check time (9 AM - 5 PM)
        if (hour < 9 || hour > 17 || (hour == 17 && minute > 0)) {
            showMessage("Time must be between 9:00 AM and 5:00 PM.");
            return;
        }

        // Time validation passed
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
        String formattedTime = sdf.format(calendar.getTime());
        showMessage("Appointment booked for " + formattedTime + " under the name " + name + ".");
    }

    private void showMessage(String message) {
        messageTextView.setText(message);
        messageTextView.setVisibility(View.VISIBLE);
    }
}
