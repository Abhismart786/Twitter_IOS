package com.example.assignemnt;



import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class VisitDateActivity extends AppCompatActivity {

    private DatePicker datePicker;
    private EditText destinationEditText;
    private Button submitButton;
    private TextView messageTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visit_date);

        datePicker = findViewById(R.id.datePicker);
        destinationEditText = findViewById(R.id.destinationEditText);
        submitButton = findViewById(R.id.submitButton);
        messageTextView = findViewById(R.id.messageTextView);
        messageTextView.setVisibility(View.GONE); // Initially hidden

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateAndSubmit();
            }
        });
    }

    private void validateAndSubmit() {
        String destination = destinationEditText.getText().toString().trim();

        // Get selected date
        int day = datePicker.getDayOfMonth();
        int month = datePicker.getMonth();
        int year = datePicker.getYear();

        Calendar selectedDate = Calendar.getInstance();
        selectedDate.set(year, month, day);

        // Check destination
        if (destination.isEmpty()) {
            showMessage("Destination cannot be empty.");
            return;
        }

        // Check if selected date is in the future
        Calendar currentDate = Calendar.getInstance();
        if (selectedDate.before(currentDate)) {
            showMessage("Please select a future date.");
            return;
        }

        // Date validation passed
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String formattedDate = sdf.format(selectedDate.getTime());
        showMessage("Trip booked to " + destination + " on " + formattedDate + ".");
    }

    private void showMessage(String message) {
        messageTextView.setText(message);
        messageTextView.setVisibility(View.VISIBLE);
    }
}
