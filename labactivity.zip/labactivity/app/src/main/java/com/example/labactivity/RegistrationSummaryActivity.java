package com.example.labactivity;





import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class RegistrationSummaryActivity extends AppCompatActivity {

    private TextView summaryTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_summary);

        summaryTextView = findViewById(R.id.summaryTextView);

        // Receive data from Intent
        String name = getIntent().getStringExtra("NAME");
        String email = getIntent().getStringExtra("EMAIL");
        String phone = getIntent().getStringExtra("PHONE");
        String attendanceType = getIntent().getStringExtra("ATTENDANCE_TYPE");
        String mealType = getIntent().getStringExtra("MEAL_TYPE");
        boolean glutenFree = getIntent().getBooleanExtra("GLUTEN_FREE", false);
        boolean nutFree = getIntent().getBooleanExtra("NUT_FREE", false);
        boolean dairyFree = getIntent().getBooleanExtra("DAIRY_FREE", false);
        boolean termsAccepted = getIntent().getBooleanExtra("TERMS_ACCEPTED", false);

        // Create summary
        StringBuilder summaryBuilder = new StringBuilder();
        summaryBuilder.append("Name: ").append(name).append("\n")
                .append("Email: ").append(email).append("\n")
                .append("Phone: ").append(phone).append("\n")
                .append("Attendance Type: ").append(attendanceType).append("\n");

        if ("In-person".equals(attendanceType)) {
            summaryBuilder.append("Meal Type: ").append(mealType).append("\n");
            summaryBuilder.append("Dietary Restrictions: ")
                    .append(glutenFree ? "Gluten Free " : "")
                    .append(nutFree ? "Nut Free " : "")
                    .append(dairyFree ? "Dairy Free" : "").append("\n");
        }

        summaryBuilder.append("Terms Accepted: ").append(termsAccepted ? "Yes" : "No");

        summaryTextView.setText(summaryBuilder.toString());
    }
}
