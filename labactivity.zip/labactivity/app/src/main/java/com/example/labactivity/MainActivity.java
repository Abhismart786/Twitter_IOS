package com.example.labactivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nameEditText, emailEditText, phoneEditText;
    private RadioGroup attendanceTypeGroup, mealTypeGroup;
    private CheckBox glutenFreeCheckBox, nutFreeCheckBox, dairyFreeCheckBox, termsCheckBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameEditText = findViewById(R.id.nameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        attendanceTypeGroup = findViewById(R.id.attendanceTypeGroup);
        mealTypeGroup = findViewById(R.id.mealTypeGroup);
        glutenFreeCheckBox = findViewById(R.id.glutenFreeCheckBox);
        nutFreeCheckBox = findViewById(R.id.nutFreeCheckBox);
        dairyFreeCheckBox = findViewById(R.id.dairyFreeCheckBox);
        termsCheckBox = findViewById(R.id.termsCheckBox);

        Button submitButton = findViewById(R.id.submitButton);
        Button resetButton = findViewById(R.id.resetButton);

        submitButton.setOnClickListener(v -> submitForm());
        resetButton.setOnClickListener(v -> resetForm());
    }

    private void submitForm() {
        String name = nameEditText.getText().toString();
        String email = emailEditText.getText().toString();
        String phone = phoneEditText.getText().toString();

        if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int selectedAttendance = attendanceTypeGroup.getCheckedRadioButtonId();
        if (selectedAttendance == -1) {
            Toast.makeText(this, "Please select attendance type", Toast.LENGTH_SHORT).show();
            return;
        }

        String attendanceType = ((RadioButton) findViewById(selectedAttendance)).getText().toString();

        if (attendanceType.equals("In-person")) {
            int selectedMeal = mealTypeGroup.getCheckedRadioButtonId();
            if (selectedMeal == -1) {
                Toast.makeText(this, "Please select meal type", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        if (!termsCheckBox.isChecked()) {
            Toast.makeText(this, "You must accept the terms and conditions", Toast.LENGTH_SHORT).show();
            return;
        }

        // Pass data to RegistrationSummaryActivity
        Intent intent = new Intent(this, RegistrationSummaryActivity.class);
        intent.putExtra("NAME", name);
        intent.putExtra("EMAIL", email);
        intent.putExtra("PHONE", phone);
        intent.putExtra("ATTENDANCE_TYPE", attendanceType);
        if (attendanceType.equals("In-person")) {
            String mealType = ((RadioButton) findViewById(mealTypeGroup.getCheckedRadioButtonId())).getText().toString();
            intent.putExtra("MEAL_TYPE", mealType);
            intent.putExtra("GLUTEN_FREE", glutenFreeCheckBox.isChecked());
            intent.putExtra("NUT_FREE", nutFreeCheckBox.isChecked());
            intent.putExtra("DAIRY_FREE", dairyFreeCheckBox.isChecked());
        }
        intent.putExtra("TERMS_ACCEPTED", termsCheckBox.isChecked());

        startActivity(intent);
    }

    private void resetForm() {
        nameEditText.setText("");
        emailEditText.setText("");
        phoneEditText.setText("");
        attendanceTypeGroup.clearCheck();
        mealTypeGroup.clearCheck();
        glutenFreeCheckBox.setChecked(false);
        nutFreeCheckBox.setChecked(false);
        dairyFreeCheckBox.setChecked(false);
        termsCheckBox.setChecked(false);
    }
}
